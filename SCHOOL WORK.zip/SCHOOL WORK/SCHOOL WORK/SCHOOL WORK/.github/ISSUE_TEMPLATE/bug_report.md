---
name: Bug Report
about: Create a report to help us improve
title: 'Bug: '
labels: bug
assignees: ''

---

**Describe the bug:**


**Screen recording:**


*MAKE SURE THIS ISSUE IS CORRECT ACCORDING TO [THE RULES](https://github.com/rxzyx/Blooket-Hacks/issues/156)*
