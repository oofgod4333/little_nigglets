---
name: Feature request
about: Suggest an idea for this project
title: "[REQUEST]"
labels: enhancement
assignees: rxzyx

---

**Describe the feature you want:**
e.g. I want [a feature] for [gamemode]

**Why do you want this feature?**
e.g. It makes the game way easier!

**How will this improve your way of playing?**
e.g. I will use it alot!
