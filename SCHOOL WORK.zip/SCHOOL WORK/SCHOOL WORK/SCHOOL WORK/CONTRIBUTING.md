## Contributing to Blooket-Hacks

By contributing to this repository, you agree the terms of the License [BSD 3-Clause License](https://github.com/rxzyx/Blooket-Hacks/blob/main/LICENSE).

All you have to do is submit a pull request, and I will review it, please use the correct (and include it) format that's found in README.MD Features.

```
Hack Branch
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/README.MD">My Hack</a> - Hack description.
```

If I agree and approve of the added work, it will be merged, however; if I think it needs to be edited, I'll give you some helpful comments in order to change your work.
