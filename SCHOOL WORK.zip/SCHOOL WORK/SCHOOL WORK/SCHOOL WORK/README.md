<h1 align="center">Blooket Hack</h1>
<h3 align="center">One of the best Blooket hacks.</h3>

#### Made by rxzyx (rzx). This is purley for education purposes.
- 📫 Have a problem or a request? **Just open an issue (with the right preferences) and I will do my best to respond.**

## How To Use:
#### Desktop: 
1. Open the file you find interesting.
2. Use the copy button on the file, or click "Raw" and copy it all.
3. Open the Inspect tool.
4. Switch to the Console.
5. Paste the script.
6. Click enter.

## Features:
- Default Scripts:
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Default-Scripts/Add-Tokens-and-XP.js">Add Tokens and XP</a> - Collect the maximum Tokens and XP currently availible.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Default-Scripts/All-Answers-Correct.js">All Answers Correct</a> - Always get the correct answer.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Default-Scripts/Anti-Ban.js">Anti-Ban</a> - Prevent your account from being suspended. If you don't want to run this every time, you can use the <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Default-Scripts/Tampermonkey/Anti-Ban.js">Tampermonkey Version</a>.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Default-Scripts/Bypass-Random-Nickname.js">Bypass Random Nickname</a> - Set your random nickname in a live game.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Default-Scripts/Custom-Blooks.js">Custom Blooks</a> - Spoof your Custom Blooks with IDs, no matter if you unlocked the accessories or not!
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Default-Scripts/Flood-Game.js">Flood Game</a> - Flood the game that you are in.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Default-Scripts/Get-Folder.js">Get Folder</a> - Make a folder in the My-Sets page without the Blooket Plus plan.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Default-Scripts/Manipulate-Plus.js">Manipulate Plus</a> - Gives you access in a spoof to play gamemodes that only Plus and/or Plus Flex members can play.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Default-Scripts/Select-Any-Blook.js">Select Any Blook</a> - Be able to select any Blook before the game starts, including Mysticals and test Blooks!
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Default-Scripts/Sell-Dupes.js">Sell Dupes</a> - Sell all of your duplicate Blooks, so you have one (or zero) of each.



- Host:
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Default-Scripts/Host/End-Game.js">End Game</a> - End the game.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Default-Scripts/Host/Kick-All.js">Kick All</a> - Kick all players that are currently in the game.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Default-Scripts/Host/Remove-Player.js">Remove Player</a> - Remove a specific player from a game.


- Flappy Blook (game to play while waiting for host to start):
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Flappy-Blook/Remove-Pipes.js">Remove Pipes</a> - Removes all the pipes.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Flappy-Blook/Set-Score.js">Set Score</a> - Set your score to whatever you want.


- Santa's Workshop
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Santas-Workshop/Set-Toys.js">Set Toys</a> - Set your toys to whatever you want.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Santas-Workshop/Set-Toys-Per-Question.js">Set Toys Per Question</a> - Set your toys per question to whatever you want.


- Gold Quest:
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Gold-Quest/Chest-ESP.js">Chest ESP</a> - See through Chests.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Gold-Quest/Set-Gold.js">Set Gold</a> - Set your Gold to whatever you want.


- Monster Brawl:
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Monster-Brawl/Invincibility.js">Invincibility</a> - Never take damage from enemies.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Monster-Brawl/Max%Abilities.js">Max Abilities</a> - Set all your current abilities' level to 9.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Monster-Brawl/Set-Level.js">Set Level</a> - Set your level to whatever you want.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Monster-Brawl/Set-XP.js">Set XP</a> - Set your XP to whatever you want.


- Crypto Hack:
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Crypto-Hack/Auto-Input-Password.js">Auto Input Password</a> - Automatically inputs the right password in during a hack.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Crypto-Hack/Set-Crypto.js">Set Crypto</a> - Set your crypto to whatever you want.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Crypto-Hack/Set-Password.js">Set Password</a> - Set your password to whatever you want.


- Fishing Frenzy:
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Fishing-Frenzy/Set-Weight.js">Set Weight</a> - Set your weight to whatever you want.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Fishing-Frenzy/Set-Frenzy-Mode.js">Set Frenzy Mode</a> - Set the mode to Frenzy.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Fishing-Frenzy/Set-Lure-Rank.js">Set Lure Rank</a> - Set your lure rank to whatever you want.


- Deceptive Dinos:
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Deceptive-Dinos/Set-Fossils.js">Set Fossils</a> - Set your fossils to whatever you want.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Deceptive-Dinos/Fossil-Multiplier.js">Fossil Multiplier</a> - Set your fossil multiplier to whatever you want.


- Blook Rush:
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Blook-Rush/Set-Blooks.js">Set Blooks</a> - Set your blooks to whatever you want
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Blook-Rush/Set-Defense.js">Set Defense</a> - Set your defense to whatever you want.


- Tower Defense:
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Tower-Defense/Clear-Enemies.js">Clear Enemies</a> - Clear the enemies on the screen.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Tower-Defense/Overpowered-Towers.js">Overpowered Towers</a> - Make all of your towers overpowered.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Tower-Defense/Place-Blooks-Anywhere.js">Place Blooks Anywhere</a> - Be able to place towers in restricted spots.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Tower-Defense/Set-Damage.js">Set Damage</a> - Set your damage to whatever you want.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Tower-Defense/Set-Tokens.js">Set Tokens</a> - Set your in-game tokens to whatever you want.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Tower-Defense/Set-Round.js">Set Round</a> - Set the round to whatever you want.


- Café:
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Cafe/Set-Cash.js">Set Cash</a> - Set your cash.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Cafe/Max-Level-Items.js">Max Level Items</a> - Set the items you have to the maximum level.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Cafe/Stock-Unlimited-Food.js">Stock Unlimited Food</a> - Set the stock of each currently unlocked food to 99.


- Factory:
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Factory/Add-Mega-Bot.js">Add Mega Bot</a> - Set all factory cards to Mega Bot.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Factory/Block-Warnings.js">Block Warnings</a> - Never receive in-game warnings.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Factory/Set-Cash.js">Set Cash</a> - Set your cash to whatever you want.


- Racing:
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Racing/Instant-Win.js">Instant Win</a> - Win racing. <I>(NOTE: Once the hack is used, get one question right to win)</I>


- Tower of Doom:
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Tower-Of-Doom/Bad-Enemy.js">Bad Enemy</a> - Minimize the opponent's cards' stats.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Tower-Of-Doom/Set-Coins.js">Set Coins</a> - Set your coins to whatever you want.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Tower-Of-Doom/Set-Health.js">Set Health</a> - Set your health to whatever you want.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Tower-Of-Doom/Max-Stats.js">Max Stats</a> - Maximize your cards' stats.


#### I am not responsible for your actions with these cheats.

<h3 align="left">Made With JavaScript:</h3>
<p align="left"> <a href="https://developer.mozilla.org/en-US/docs/Web/JavaScript" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-original.svg" alt="javascript" width="40" height="40"/> </a> </p>

#### Copyright &copy; 2022 rzx.
